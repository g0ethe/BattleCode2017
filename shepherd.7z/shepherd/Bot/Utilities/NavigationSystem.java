package shepherd.Bot.Utilities;

public class NavigationSystem {

}
