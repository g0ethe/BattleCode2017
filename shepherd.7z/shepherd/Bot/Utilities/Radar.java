package shepherd.Bot.Utilities;

public class Radar {

}
