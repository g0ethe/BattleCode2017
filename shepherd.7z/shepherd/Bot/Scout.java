package shepherd.Bot;

import battlecode.common.GameActionException;
import battlecode.common.RobotController;
import shepherd.Bot.Behaviour.Behaviour;
import shepherd.Bot.Behaviour.Scout.IdleScoutBehaviour;

public class Scout extends Bot {

	RobotController scout;

	public Scout(RobotController rc) {
		scout = rc;
	}

	public Behaviour getBehaviour() throws GameActionException {
		if(behaviour == null) return new IdleScoutBehaviour();
		if(behaviour instanceof IdleScoutBehaviour) return behaviour;
		return new IdleScoutBehaviour();
	}

}
