package shepherd.Bot;

import battlecode.common.GameActionException;
import battlecode.common.RobotController;
import shepherd.Bot.Behaviour.Behaviour;
import shepherd.Bot.Behaviour.Gardener.IdleGardenerBehaviour;

public class Gardener extends Bot {

	RobotController gardener;

	public Gardener(RobotController rc) {
		gardener = rc;
	}

	public Behaviour getBehaviour() throws GameActionException {
		if(behaviour == null) return new IdleGardenerBehaviour();
		if(behaviour instanceof IdleGardenerBehaviour) return behaviour;
		return new IdleGardenerBehaviour();
	}

}
