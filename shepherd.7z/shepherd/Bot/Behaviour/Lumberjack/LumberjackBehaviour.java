package shepherd.Bot.Behaviour.Lumberjack;

import shepherd.Bot.Behaviour.Behaviour;

public abstract class LumberjackBehaviour extends Behaviour {

}
