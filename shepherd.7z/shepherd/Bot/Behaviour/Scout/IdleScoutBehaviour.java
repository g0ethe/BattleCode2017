package shepherd.Bot.Behaviour.Scout;

import battlecode.common.Clock;
import battlecode.common.GameActionException;

public class IdleScoutBehaviour extends ScoutBehaviour {

	public void execute() throws GameActionException {
		Clock.yield();
	}

}
