package shepherd.Bot.Behaviour.Scout;

import shepherd.Bot.Behaviour.Behaviour;

public abstract class ScoutBehaviour extends Behaviour {

}
