package shepherd.Bot.Behaviour.Tank;

import shepherd.Bot.Behaviour.Behaviour;

public abstract class TankBehaviour extends Behaviour {

}
