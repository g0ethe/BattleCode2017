package shepherd.Bot.Behaviour;

import battlecode.common.GameActionException;

public abstract class Behaviour {

	public abstract void execute() throws GameActionException;

}
