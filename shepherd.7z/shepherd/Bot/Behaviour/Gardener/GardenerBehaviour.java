package shepherd.Bot.Behaviour.Gardener;

import shepherd.Bot.Behaviour.Behaviour;

public abstract class GardenerBehaviour extends Behaviour {

}
