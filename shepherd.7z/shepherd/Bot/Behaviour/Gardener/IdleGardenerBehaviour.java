package shepherd.Bot.Behaviour.Gardener;

import battlecode.common.Clock;
import battlecode.common.GameActionException;

public class IdleGardenerBehaviour extends GardenerBehaviour {

	public void execute() throws GameActionException {
		Clock.yield();
	}

}
