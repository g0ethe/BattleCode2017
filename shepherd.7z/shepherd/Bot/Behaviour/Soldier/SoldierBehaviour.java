package shepherd.Bot.Behaviour.Soldier;

import shepherd.Bot.Behaviour.Behaviour;

public abstract class SoldierBehaviour extends Behaviour {

}
