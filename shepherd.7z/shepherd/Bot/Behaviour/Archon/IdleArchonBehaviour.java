package shepherd.Bot.Behaviour.Archon;

/**
 * Idle Behaviour for test purposes
 */

import battlecode.common.Clock;
import battlecode.common.GameActionException;

public class IdleArchonBehaviour extends ArchonBehaviour {

	public void execute() throws GameActionException {
		Clock.yield();
	}

}
