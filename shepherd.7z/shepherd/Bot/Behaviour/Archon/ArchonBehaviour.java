package shepherd.Bot.Behaviour.Archon;

import shepherd.Bot.Behaviour.Behaviour;

public abstract class ArchonBehaviour extends Behaviour {

}
