package shepherd.Bot;

import battlecode.common.GameActionException;
import battlecode.common.RobotController;
import shepherd.Bot.Behaviour.Behaviour;
import shepherd.Bot.Behaviour.Archon.IdleArchonBehaviour;

public class Archon extends Bot {

	RobotController archon;

	public Archon(RobotController rc) {
		archon = rc;
	}

	public Behaviour getBehaviour() throws GameActionException {
		if(behaviour == null) return new IdleArchonBehaviour();
		if(behaviour instanceof IdleArchonBehaviour) return behaviour;
		return new IdleArchonBehaviour();
	}

}
