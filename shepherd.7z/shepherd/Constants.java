package shepherd;

public class Constants {

}
